/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaanmodelxyz;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author ACER
 */
public class TransaksiPeminjaman {

   private Buku buku;
   private AnggotaPerpustakaan anggota;
   private Date tanggal;
   private int IdTransaksi;

    public int getIdTransaksi() {
        return IdTransaksi;
    }

    public void setIdTransaksi(int IdTransaksi) {
        this.IdTransaksi = IdTransaksi;
    }

    public Buku getBuku() {
        return buku;
    }

    public void setBuku(Buku buku) {
        this.buku = buku;
    }

    public AnggotaPerpustakaan getAnggota() {
        return anggota;
    }

    public void setAnggota(AnggotaPerpustakaan anggota) {
        this.anggota = anggota;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }
   

    public TransaksiPeminjaman(int IdTransaksi, Buku buku, AnggotaPerpustakaan anggota, Date tanggal) {
        this.IdTransaksi = IdTransaksi;
        this.buku = buku;
        this.anggota = anggota;
        this.tanggal = tanggal;
    }

    boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
           
    
}
