/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package perpustakaanmodelxyz;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author ACER
 */



public class PerpustakaanModelXYZ {
    
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // TODO code application logic here
        Admin admin = new Admin("moza","moza123");
        Buku buku = new Buku("Laskar Pelangi",1,"Mozaa",true);
        Buku buku2 = new Buku("Transforemrs",2,"Ghozali",true);
        Buku buku3 = new Buku("naruto",3,"ATIKAH",true);
        AnggotaPerpustakaan anggota = new AnggotaPerpustakaan("Atikah",1,"Metro","tIKAHH","2217");
        
        ////////////////////////////////////////// TAMBAH, HAPUS, DAN OUTPUT DAFTAR BUKU ADMIN
        // TAMBAH BUKU
        admin.tambahkoleksibuku(buku);
        admin.tambahkoleksibuku(buku2);
        admin.tambahkoleksibuku(buku3);
        //HAPUS BUKU
        admin.hapusbuku(buku);    
         
//         
//         //MENGELUARKAN ISI DAFTAR BUKU
        ArrayList<Buku>DaftarBuku = admin.getDaftarBuku();
        System.out.println("     -----------------------------");
        System.out.println("     ||DAFTAR BUKU YANG TERSEDIA||");
        System.out.println("     -----------------------------");
        for(Buku loo : DaftarBuku){
            System.out.println("Judul Buku\t\t: " + loo.getJudul());
            System.out.println("Nama Pengarang\t\t: " + loo.getPengarang());
            System.out.println("Nomor ISBN\t\t: " + loo.getNoISBN());
            System.out.println("");
  
    }
        
         ////////////////////////////////////////// Anggota Meminjam,mengembalikan, cari BUKU
        
        //CARI BUKU        
        anggota.cariBuku(admin, "naruto");
         //PINJAM DAN KEMBALI BUKU
        Date d1 = new Date();
        anggota.pinjambuku(1, buku, anggota,d1 );
        anggota.kembalibuku(1, buku, anggota, d1);


        //////////////////////////////////////////Admin Liat daftar transaksi dan histori      
        admin.lihatdaftartransaksi(anggota);
        admin.liatHistoriAnggota(anggota);
        }


        
          
      
    
    
    
}


    


//System.out.println("Selamat datang di Sistem Informasi Perpustakaan XYZ");   
//        System.out.println("Login sebagai apa ?");
//        System.out.println("1.Admin");
//        System.out.println("2.Anggota");
//        System.out.println("Masukkan pilihan anda : ");
//        String us;
//        String pass;
//        int pilihan = input.nextInt();
//        input.nextLine();
//        if(pilihan == 1){
//           System.out.println("Masukkan username  : ");
//           us = input.nextLine();
//           System.out.println("Masukkan password : ");
//           pass = input.nextLine();
//           Admin admin = new Admin(us, pass);
//           System.out.println("Masukkan email anda lagi : ");
//           us = input.nextLine();
//           System.out.println("Masukkan password anda lagi : ");
//           pass = input.nextLine();
//           admin.izinmasuk(us, pass);
//           while(true){
//           if(admin.izinmasuk(us, pass) == true){
//               System.out.println("Masuk ke aplikasi");
//               System.out.println("Apa yang ingin kamu lakukukan ? : ");
//               System.out.println("1.Tambah buku");
//               System.out.println("2.Hapus buku");
//               System.out.println("3.Lihat daftar buku");
//               System.out.println("Masukkan pilihan kamu : ");
//               pilihan = input.nextInt();
//               input.nextLine();
//               if(pilihan ==1){
//                   System.out.println("Masukkan judul : ");
//                   String judul = input.nextLine();
//                   System.out.println("Masukkan nomor isbn : ");
//                   int isbn = input.nextInt();
//                   input.nextLine();
//                   System.out.println("Masukkan nama pengarang : ");
//                   String pengarang = input.nextLine();
//                   boolean benar = true;
//                   Buku buku = new Buku(judul,isbn,pengarang,benar);
//                   admin.tambahkoleksibuku(buku);
//                   
//  
//    }if(pilihan == 2){
//        
//                   String judul = "a";
//                   System.out.println("Masukkan nomor isbn : ");
//                   int isbn = input.nextInt();
//                   input.nextLine();
//                  
//                   String pengarang ="a";
//                   boolean benar = true;
//                   Buku buku = new Buku(judul,isbn,pengarang,benar);
//                   admin.hapusbuku(buku);
//                   
//    }
//    
//    if(pilihan == 3){
//        ArrayList<Buku>DaftarBuku = admin.getDaftarBuku(); 
//        System.out.println("     -----------------------------");
//        System.out.println("     ||DAFTAR BUKU YANG TERSEDIA||");
//        System.out.println("     -----------------------------");
//        for(Buku loo : DaftarBuku){
//            System.out.println("Judul Buku\t\t: " + loo.getJudul());
//            System.out.println("Nama Pengarang\t\t: " + loo.getPengarang());
//            System.out.println("Nomor ISBN\t\t: " + loo.getNoISBN());
//            System.out.println("");
//    
//    }
//    }
//               }
//           }
//           
//               
//               
//               
//           }else if(pilihan == 2){
//               
//           }
//           
//            
//        }
//
